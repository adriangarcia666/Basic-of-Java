
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num = 5;
		
		
		//if - else 
		/*sentencia de control verdadero o falso*/
		
		
		if(num < 10) {
			
			//instrucciones
			System.out.println("el numero es menor a 10");
			
		}
		
		else {
			//instrucciones
		System.out.println("el numero es mayor a 10");
		
		}
		
		
		
	}

}
