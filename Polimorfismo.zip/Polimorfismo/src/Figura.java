
public class Figura {

	
	private float base;
	
	
	
	
	
	
	
	public Figura() {
		super();
	}

	
	
	
	
	
	public Figura(float base) {
		super();
		//this.base = base;
		//this.base = base<0?0:base;
		setBase(base);
	}






	public float getBase() {
		return base;
	}

	public void setBase(float base) {
		this.base = base<0?0:base;
		
	
	}

	public float getArea() {
		return base;
	}
	
	public float getPerimetro() {
		return base;
	}
	
}
