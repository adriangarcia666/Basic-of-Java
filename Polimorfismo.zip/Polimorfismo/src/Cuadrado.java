
public class Cuadrado  extends Figura{
	
	
	private float altura;
	
	
	

	public Cuadrado() {
		super();
	}
	
	
	
	

	public Cuadrado(float altura,float base) {
		 super(base);
		 setAltura(altura);
		 //setBase(base);
	}





	public float getAltura() {
		return altura;
	}

	public void setAltura(float altura) {
		this.altura = altura<0?0:altura;
	}

	@Override
	public float getArea() {
		// TODO Auto-generated method stub
		return super.getArea()*getAltura();
	}

	@Override
	public float getPerimetro() {
		// TODO Auto-generated method stub
		return super.getPerimetro()*4;
	}
	
	

}
