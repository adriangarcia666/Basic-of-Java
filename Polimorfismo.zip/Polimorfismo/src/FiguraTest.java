
public class FiguraTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Figura figura01=new Figura();
		
		//figura01.base=4;
		figura01.setBase(5);
		
		//System.out.println(figura01.base);
		System.out.println(figura01.getBase());

		
		Figura figura02=new Figura(6);
		System.out.println(figura02.getBase());
		
		
		
	//poliformismo son metodos con el mismo nombre pero diferente comportamiento	
		Figura cuadrado=new Cuadrado(12, 20);
		System.out.println(cuadrado.getArea());
		
		Figura circulo=new Circulo(12);
		System.out.println(circulo.getArea());
		
		
		Figura f=new Figura(12);
		System.out.println(f.getArea());
		
		

	}

}
