
public class Circulo  extends Figura{
	
	
	private float radio;
	
	
	
	
	

	public Circulo() {
		super();
	}
	
	

	public Circulo(float radio) {
		super();
		this.radio = radio;
	}

	public float getRadio() {
		return radio;
	}

	public void setRadio(float radio) {
		this.radio = radio<0?0:radio;
	}



	@Override
	public float getArea() {
		// TODO Auto-generated method stub
		return (float) (Math.PI * Math.pow(getRadio(),2) );
	}



	@Override
	public float getPerimetro() {
		// TODO Auto-generated method stub
		return  (float) (( getRadio()*2) *(Math.PI));
	}
	
	
	
	
	
	

}
