package poo;

public class Main {

	public static void main(String[] args) {
	
		System.out.println("Inicio de programa");
		
		Persona hombre = new Persona();  
		//Tipo = Persona    hombre = Tipo del objeto   y mandamos a llamar a su constructor
		Persona mujer = new Persona();
		
		System.out.println();
		
		

		
		
	}

	//que es un objeto?
	// es una abstraccion de la realidad
	
	//que es una clase?
	// es la abtraccion de un objeto en un lenguaje de programacion
}
