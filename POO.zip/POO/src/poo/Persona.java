package poo;

public class Persona {

	//atributos o caracteristicas
	
	String nombre,apellido,apodo;
	int edad,altura,peso;
	
	
	//metodo o funciones
	
		public void comer() {
	
	
		}
	 	
		public void caminar() {
			
			
		}
	
		public void correr() {
			
			
		}
	
		public void dormir() {
			
			
		}
	
}
